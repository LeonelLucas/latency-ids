Definitive multi-dataset ML-IDS experiment
Runner version: 2026-09-26.1
Run stamp: 20260930T225117Z

Included:
- source/configuration snapshot
- experiment logs
- host metadata and benchmark monitoring
- analysis outputs
- predictive metrics
- training metadata
- benchmark metadata
- processed dataset manifests
- hashes of large excluded artifacts

Intentionally excluded from this compact package:
- raw source datasets
- processed dataset.npz files
- trained model .joblib files
- prediction_scores.npz files

The complete execution remains available at:
/home/lleonel/DisserTest/latency-ids/multidataset-run-20260930T225117Z
